@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\pythonw.exe" (
    echo.
    echo Mi IA no esta instalada correctamente.
    echo Ejecuta REPARAR_E_INSTALAR_MI_IA.cmd desde el paquete 1.0.2.
    echo.
    pause
    exit /b 1
)

start "" ".venv\Scripts\pythonw.exe" "%~dp0main.py"
exit /b 0
