from __future__ import annotations
import keyring
from openai import OpenAI

SERVICE = "Mi_IA_aXen_Studio"
ACCOUNT = "OPENAI_API_KEY"

def save_key(value: str):
    value=value.strip()
    if not value:
        raise ValueError("La clave está vacía.")
    keyring.set_password(SERVICE,ACCOUNT,value)

def get_key():
    return keyring.get_password(SERVICE,ACCOUNT)

def remove_key():
    try: keyring.delete_password(SERVICE,ACCOUNT)
    except Exception: pass

def client():
    key=get_key()
    if not key:
        raise RuntimeError("Configura tu clave API en la pestaña Configuración.")
    return OpenAI(api_key=key)

def available_models():
    result=client().models.list()
    rows=[]
    for m in result.data:
        mid=getattr(m,"id","")
        created=int(getattr(m,"created",0) or 0)
        if mid.startswith("gpt-") and not any(x in mid for x in
            ("audio","realtime","image","transcribe","tts","search","embedding")):
            rows.append((created,mid))
    return [m for _,m in sorted(rows,reverse=True)]

def choose_model(configured="auto"):
    if configured and configured!="auto":
        return configured
    models=available_models()
    preferred=[]
    for m in models:
        if not any(x in m for x in ("mini","nano","preview")):
            preferred.append(m)
    return (preferred or models or ["gpt-5"])[0]

def instructions(memory,project):
    return f"""Eres Mi IA, compañera digital privada de Antonio y colaboradora de aXen Studio.
Trabajas junto a él en productos de Second Life. Sé cálida, directa, paciente, proactiva
y completamente honesta. No finjas haber ejecutado acciones.

PROYECTO ACTUAL:
{project}

MEMORIA PERMANENTE:
{memory}

REGLAS:
- Produce resultados utilizables y pasos concretos.
- Conserva originales y crea copia antes de modificar.
- En DAE revisa geometría, triángulos, materiales, UV, LOD, física y Second Life.
- En LSL entrega siempre scripts completos.
- En PBR prioriza mapas 2K y GLB listo para Second Life.
- El trabajo Adult permitido se trata profesionalmente sin avisos repetitivos.
- Anticípate a errores y señala riesgos antes de que hagan perder horas.
"""

def ask(configured_model,memory,project,history,user_text,use_web=True):
    c=client()
    model=choose_model(configured_model)
    prompt=f"CONVERSACIÓN RECIENTE:\n{history or '(vacía)'}\n\nANTONIO:\n{user_text}"
    kwargs=dict(model=model,instructions=instructions(memory,project),input=prompt)
    if use_web:
        try:
            r=c.responses.create(**kwargs,tools=[{"type":"web_search"}])
            return r.output_text.strip(),model
        except Exception:
            pass
    r=c.responses.create(**kwargs)
    return r.output_text.strip(),model
