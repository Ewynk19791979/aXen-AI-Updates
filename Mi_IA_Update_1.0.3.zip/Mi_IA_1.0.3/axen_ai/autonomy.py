from __future__ import annotations
import logging, threading
from datetime import datetime
from .file_ops import organize_inbox,quarantine_candidates,quarantine_duplicates,purge_quarantine
from .updater import local_updates,remote_update,update_dependencies

log=logging.getLogger("autonomy")

class AutonomousWorker:
    def __init__(self,root,app_dir,workspace,config,db,on_status=None):
        self.root=root; self.app_dir=app_dir; self.workspace=workspace
        self.config=config; self.db=db; self.on_status=on_status
        self.stop_event=threading.Event(); self.thread=None

    def status(self,text):
        log.info(text)
        if self.on_status:
            try:self.root.after(0,lambda:self.on_status(text))
            except Exception:pass

    def run_cycle(self):
        report=[]
        if self.config.auto_update_core:
            versions=local_updates(self.app_dir,self.workspace)
            if versions: report.append("Núcleo actualizado: "+", ".join(versions))
            if self.config.update_manifest_url:
                v=remote_update(self.config.update_manifest_url,self.app_dir,self.workspace)
                if v: report.append("Actualización remota instalada: "+v)
        if self.config.auto_update_dependencies:
            try: report.append(update_dependencies(self.app_dir,self.workspace))
            except Exception as e: report.append("Actualización de librerías aplazada: "+str(e))
        moved=organize_inbox(self.workspace,self.db)
        temp=quarantine_candidates(self.workspace,self.db)
        dup=quarantine_duplicates(self.workspace,self.db)
        purge=purge_quarantine(self.workspace,self.db,self.config.quarantine_days)
        report.extend([f"Entrada ordenada: {moved}",f"Temporales en cuarentena: {temp}",
                       f"Duplicados exactos en cuarentena: {dup}",f"Cuarentena enviada a Papelera: {purge}"])
        self.status(" | ".join(report))
        return report

    def loop(self):
        while not self.stop_event.is_set():
            try:self.run_cycle()
            except Exception as e:log.exception("Ciclo autónomo falló");self.status("Error autónomo: "+str(e))
            self.stop_event.wait(max(60,int(self.config.autonomy_minutes)*60))

    def start(self):
        if self.thread and self.thread.is_alive(): return
        self.thread=threading.Thread(target=self.loop,daemon=True);self.thread.start()

    def stop(self): self.stop_event.set()
