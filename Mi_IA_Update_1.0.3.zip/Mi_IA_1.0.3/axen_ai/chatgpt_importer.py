from __future__ import annotations
import json, zipfile
from pathlib import Path

def _message_text(message):
    content=(message or {}).get("content") or {}
    parts=content.get("parts") or []
    out=[]
    for p in parts:
        if isinstance(p,str): out.append(p)
        elif isinstance(p,dict): out.append(json.dumps(p,ensure_ascii=False))
    return "\n".join(out).strip()

def import_export(zip_path: Path, db, output_dir: Path, max_items=0):
    output_dir.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(zip_path) as z:
        names=z.namelist()
        conv_name=next((n for n in names if n.endswith("conversations.json")),None)
        if not conv_name:
            raise ValueError("No se encontró conversations.json dentro del ZIP.")
        conversations=json.loads(z.read(conv_name).decode("utf-8"))
    count=0
    for conv in conversations:
        if max_items and count>=max_items: break
        title=conv.get("title") or "Sin título"
        source_id=conv.get("id") or f"conv_{count}"
        mapping=conv.get("mapping") or {}
        lines=[]
        ordered=sorted(mapping.values(),key=lambda x: ((x.get("message") or {}).get("create_time") or 0))
        for node in ordered:
            msg=node.get("message")
            if not msg: continue
            role=((msg.get("author") or {}).get("role") or "desconocido").upper()
            text=_message_text(msg)
            if text: lines.append(f"{role}:\n{text}")
        content="\n\n".join(lines)
        db.import_conversation(source_id,title,content)
        safe="".join(c if c.isalnum() or c in " _-" else "_" for c in title)[:80].strip() or source_id
        (output_dir/f"{safe}_{source_id[:8]}.txt").write_text(content,encoding="utf-8")
        count+=1
    return count
