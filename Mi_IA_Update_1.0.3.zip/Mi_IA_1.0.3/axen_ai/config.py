from __future__ import annotations
import json
from dataclasses import dataclass, asdict
from pathlib import Path

APP_NAME = "Mi IA · aXen Studio"

def preferred_workspace() -> Path:
    g = Path(r"G:\aXen_AI")
    try:
        if Path(r"G:\\").exists():
            return g
    except OSError:
        pass
    return Path.home() / "aXen_AI"

@dataclass
class AppConfig:
    workspace: str = str(preferred_workspace())
    model: str = "auto"
    web_search: bool = True
    autonomy: bool = True
    autonomy_minutes: int = 10
    auto_update_dependencies: bool = False
    auto_update_core: bool = False
    update_manifest_url: str = ""
    quarantine_days: int = 30
    import_max_conversations: int = 0

    @property
    def workspace_path(self) -> Path:
        return Path(self.workspace)

    @classmethod
    def load(cls, app_dir: Path) -> "AppConfig":
        p = app_dir / "settings.json"
        if not p.exists():
            cfg = cls()
            cfg.save(app_dir)
            return cfg
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            defaults = asdict(cls())
            values = {k: data.get(k, v) for k, v in defaults.items()}
            return cls(**values)
        except Exception:
            return cls()

    def save(self, app_dir: Path) -> None:
        (app_dir / "settings.json").write_text(
            json.dumps(asdict(self), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

WORKSPACE_DIRS = [
    "01_APP",
    "02_MEMORIA",
    "02_MEMORIA/CHATGPT_IMPORTADO",
    "02_MEMORIA/INFORMES_AUTONOMOS",
    "03_PROYECTOS",
    "04_ARCHIVOS_ENTRADA",
    "05_RESULTADOS",
    "06_PBR",
    "07_MESH/01_DAE_ORIGINALES",
    "07_MESH/02_ESTUDIOS_TECNICOS",
    "07_MESH/03_MODELOS_APRENDIDOS",
    "07_MESH/04_DAE_CORREGIDOS",
    "07_MESH/05_LOD",
    "07_MESH/06_FISICA",
    "07_MESH/07_UV_Y_MATERIALES",
    "07_MESH/08_EXPORTACION_SECOND_LIFE",
    "07_MESH/09_PLANTILLAS_AXEN",
    "08_SCRIPTS_LSL",
    "09_IMAGENES",
    "10_COPIAS_SEGURIDAD",
    "10_COPIAS_SEGURIDAD/CUARENTENA",
    "10_COPIAS_SEGURIDAD/ACTUALIZACIONES",
    "11_CONFIGURACION",
    "ACTUALIZACIONES",
]

def ensure_workspace(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)
    for rel in WORKSPACE_DIRS:
        (path / rel).mkdir(parents=True, exist_ok=True)
