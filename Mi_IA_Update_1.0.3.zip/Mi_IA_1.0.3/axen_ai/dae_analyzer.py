from __future__ import annotations
import hashlib
import xml.etree.ElementTree as ET
from pathlib import Path

def local(tag): return tag.rsplit("}",1)[-1]
def all_local(root,name): return [e for e in root.iter() if local(e.tag)==name]

def hash_file(path):
    h=hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""): h.update(chunk)
    return h.hexdigest()

def analyze(path: Path):
    root=ET.parse(path).getroot()
    geometries=all_local(root,"geometry")
    materials=all_local(root,"material")
    effects=all_local(root,"effect")
    images=all_local(root,"image")
    nodes=all_local(root,"node")
    controllers=all_local(root,"controller")
    animations=all_local(root,"animation")
    triangles=polylist=polygons=lines=0
    material_symbols=set()
    for geo in geometries:
        for e in geo.iter():
            t=local(e.tag)
            if t=="triangles": triangles+=int(e.attrib.get("count","0") or 0)
            elif t=="polylist": polylist+=int(e.attrib.get("count","0") or 0)
            elif t=="polygons": polygons+=int(e.attrib.get("count","0") or 0)
            elif t in ("lines","linestrips"): lines+=int(e.attrib.get("count","0") or 0)
            if e.attrib.get("material"): material_symbols.add(e.attrib["material"])
    refs=[]
    for img in images:
        init=next((e.text for e in img.iter() if local(e.tag)=="init_from"),"")
        refs.append((img.attrib.get("name") or img.attrib.get("id") or "sin nombre",(init or "").strip()))
    unit=next(iter(all_local(root,"unit")),None)
    axis=next(iter(all_local(root,"up_axis")),None)
    tool=next(iter(all_local(root,"authoring_tool")),None)
    return dict(
        file=str(path),size=path.stat().st_size,sha256=hash_file(path),
        collada=root.attrib.get("version","desconocida"),
        unit_name=unit.attrib.get("name","") if unit is not None else "",
        unit_meter=unit.attrib.get("meter","") if unit is not None else "",
        up_axis=(axis.text or "").strip() if axis is not None else "",
        authoring_tool=(tool.text or "").strip() if tool is not None else "",
        geometries=len(geometries),triangles=triangles,polylist=polylist,
        polygons=polygons,lines=lines,materials=len(materials),effects=len(effects),
        slots=len(material_symbols),images=len(images),refs=refs,nodes=len(nodes),
        controllers=len(controllers),animations=len(animations))

def report(d):
    warnings=[]
    if not d["geometries"]: warnings.append("No se detectaron geometrías.")
    if not d["materials"]: warnings.append("No se detectaron materiales.")
    if not d["images"]: warnings.append("El DAE no declara imágenes.")
    if not d["unit_meter"]: warnings.append("No se encontró escala métrica declarada.")
    if d["triangles"]==0 and d["polylist"]>0:
        warnings.append("Usa polylist; conviene triangular antes de exportar a Second Life.")
    if d["controllers"]: warnings.append("Contiene controladores o skin.")
    refs="\n".join(f"  - {n}: {p or '(sin ruta)'}" for n,p in d["refs"]) or "  - Ninguna"
    warn="\n".join(f"- {x}" for x in warnings) or "- Sin avisos estructurales básicos."
    return f"""ESTUDIO TÉCNICO DAE
====================
Archivo: {d['file']}
Tamaño: {d['size']:,} bytes
SHA-256: {d['sha256']}
COLLADA: {d['collada']}
Origen: {d['authoring_tool'] or 'No declarado'}
Unidad: {d['unit_name'] or 'No declarada'} | metros: {d['unit_meter'] or 'No declarado'}
Eje vertical: {d['up_axis'] or 'No declarado'}

ESTRUCTURA
Geometrías: {d['geometries']}
Nodos: {d['nodes']}
Controladores: {d['controllers']}
Animaciones: {d['animations']}

GEOMETRÍA
Triángulos declarados: {d['triangles']}
Polylist: {d['polylist']}
Polygons: {d['polygons']}
Líneas: {d['lines']}

MATERIALES Y TEXTURAS
Materiales: {d['materials']}
Efectos: {d['effects']}
Slots detectados: {d['slots']}
Imágenes: {d['images']}
Referencias:
{refs}

AVISOS
{warn}

Este informe estudia la estructura COLLADA. El Land Impact, LOD y física final
también deben verificarse dentro del cargador de Second Life.
"""
