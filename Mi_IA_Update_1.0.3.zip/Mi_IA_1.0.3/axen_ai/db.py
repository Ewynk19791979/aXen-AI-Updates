from __future__ import annotations
import sqlite3
from datetime import datetime
from pathlib import Path

class Database:
    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.path = path
        self._init()

    def connect(self):
        con = sqlite3.connect(self.path)
        con.row_factory = sqlite3.Row
        return con

    @staticmethod
    def now():
        return datetime.now().isoformat(timespec="seconds")

    def _init(self):
        with self.connect() as con:
            con.executescript("""
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS memories(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              category TEXT NOT NULL, content TEXT NOT NULL,
              priority INTEGER NOT NULL DEFAULT 5, created_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS projects(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              name TEXT NOT NULL UNIQUE, description TEXT NOT NULL DEFAULT '',
              status TEXT NOT NULL DEFAULT 'activo', created_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS messages(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              project_id INTEGER, role TEXT NOT NULL, content TEXT NOT NULL,
              created_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS actions(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              action_type TEXT NOT NULL, target TEXT NOT NULL, detail TEXT NOT NULL,
              reversible INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS dae_studies(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              file_path TEXT NOT NULL, file_hash TEXT NOT NULL,
              report TEXT NOT NULL, created_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS imported_conversations(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              source_id TEXT UNIQUE, title TEXT, content TEXT,
              created_at TEXT NOT NULL);
            """)
            if con.execute("SELECT COUNT(*) n FROM projects").fetchone()["n"] == 0:
                con.execute("INSERT INTO projects(name,description,created_at) VALUES(?,?,?)",
                            ("Tienda aXen Studio","Proyecto principal de trabajo para Second Life.",self.now()))

    def seed(self, rows):
        with self.connect() as con:
            if con.execute("SELECT COUNT(*) n FROM memories").fetchone()["n"] == 0:
                con.executemany(
                    "INSERT INTO memories(category,priority,content,created_at) VALUES(?,?,?,?)",
                    [(a,b,c,self.now()) for a,b,c in rows])

    def memories(self, limit=500):
        with self.connect() as con:
            return con.execute("SELECT * FROM memories ORDER BY priority DESC,id DESC LIMIT ?",
                               (limit,)).fetchall()

    def memory_context(self, limit=100):
        return "\n".join(f"- [{r['category']}] {r['content']}" for r in self.memories(limit))

    def add_memory(self, category, content, priority=5):
        with self.connect() as con:
            con.execute("INSERT INTO memories(category,content,priority,created_at) VALUES(?,?,?,?)",
                        (category.strip() or "general",content.strip(),int(priority),self.now()))

    def delete_memory(self, mid):
        with self.connect() as con:
            con.execute("DELETE FROM memories WHERE id=?",(mid,))

    def projects(self):
        with self.connect() as con:
            return con.execute("SELECT * FROM projects ORDER BY status,name").fetchall()

    def add_project(self,name,description=""):
        with self.connect() as con:
            con.execute("INSERT INTO projects(name,description,created_at) VALUES(?,?,?)",
                        (name.strip(),description.strip(),self.now()))

    def project(self,name):
        with self.connect() as con:
            return con.execute("SELECT * FROM projects WHERE name=?",(name,)).fetchone()

    def add_message(self,pid,role,content):
        with self.connect() as con:
            con.execute("INSERT INTO messages(project_id,role,content,created_at) VALUES(?,?,?,?)",
                        (pid,role,content,self.now()))

    def recent_messages(self,pid,limit=18):
        with self.connect() as con:
            rows=con.execute("SELECT * FROM messages WHERE project_id IS ? ORDER BY id DESC LIMIT ?",
                             (pid,limit)).fetchall()
        return list(reversed(rows))

    def action(self,kind,target,detail,reversible=True):
        with self.connect() as con:
            con.execute("INSERT INTO actions(action_type,target,detail,reversible,created_at) VALUES(?,?,?,?,?)",
                        (kind,str(target),detail,int(reversible),self.now()))

    def dae_study(self,path,file_hash,report):
        with self.connect() as con:
            con.execute("INSERT INTO dae_studies(file_path,file_hash,report,created_at) VALUES(?,?,?,?)",
                        (str(path),file_hash,report,self.now()))

    def import_conversation(self,source_id,title,content):
        with self.connect() as con:
            con.execute("""INSERT OR IGNORE INTO imported_conversations
                           (source_id,title,content,created_at) VALUES(?,?,?,?)""",
                        (source_id,title,content,self.now()))

    def search_imported(self,term,limit=10):
        with self.connect() as con:
            return con.execute("""SELECT title,content FROM imported_conversations
                                  WHERE title LIKE ? OR content LIKE ? LIMIT ?""",
                               (f"%{term}%",f"%{term}%",limit)).fetchall()
