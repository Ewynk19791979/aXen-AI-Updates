from __future__ import annotations
import hashlib, json, shutil
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path
from send2trash import send2trash

BUCKETS={
 "DAE":{".dae"},"MESH_3D":{".glb",".gltf",".obj",".fbx",".blend"},
 "TEXTURAS":{".png",".jpg",".jpeg",".tga",".bmp",".tif",".tiff",".webp"},
 "SCRIPTS":{".txt",".lsl",".py",".js",".json",".xml"},
 "PAQUETES":{".zip",".rar",".7z"},"DOCUMENTOS":{".pdf",".docx",".odt",".md"}}
TEMP_EXT={".tmp",".temp",".part",".crdownload"}
JUNK={"thumbs.db","desktop.ini",".ds_store"}

def ensure_inside(path: Path,workspace: Path):
    try: path.resolve().relative_to(workspace.resolve())
    except ValueError as e: raise PermissionError("Fuera del espacio autorizado.") from e

def digest(path):
    h=hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""): h.update(b)
    return h.hexdigest()

def unique(dest: Path):
    if not dest.exists(): return dest
    i=2
    while True:
        p=dest.with_name(f"{dest.stem}_{i}{dest.suffix}")
        if not p.exists(): return p
        i+=1

def bucket_for(path):
    ext=path.suffix.lower()
    for name,exts in BUCKETS.items():
        if ext in exts:return name
    return "OTROS"

def organize_inbox(workspace: Path,db):
    inbox=workspace/"04_ARCHIVOS_ENTRADA"
    target=workspace/"03_PROYECTOS"/"_CLASIFICADO"
    moved=0
    for p in list(inbox.iterdir()):
        if not p.is_file(): continue
        dest=unique(target/bucket_for(p)/p.name)
        dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.move(str(p),str(dest))
        db.action("ordenar",p,f"Movido a {dest}",True); moved+=1
    return moved

def quarantine_candidates(workspace: Path,db):
    quarantine=workspace/"10_COPIAS_SEGURIDAD"/"CUARENTENA"
    quarantine.mkdir(parents=True,exist_ok=True)
    moved=0
    cutoff=datetime.now()-timedelta(days=2)
    for p in list(workspace.rglob("*")):
        if not p.is_file() or quarantine in p.parents: continue
        try: modified=datetime.fromtimestamp(p.stat().st_mtime)
        except OSError: continue
        if (p.suffix.lower() in TEMP_EXT or p.name.lower() in JUNK) and modified<cutoff:
            dest=unique(quarantine/p.name)
            shutil.move(str(p),str(dest))
            db.action("cuarentena",p,f"Temporal movido a {dest}",True); moved+=1
    return moved

def quarantine_duplicates(workspace: Path,db):
    quarantine=workspace/"10_COPIAS_SEGURIDAD"/"CUARENTENA"/"DUPLICADOS"
    groups=defaultdict(list)
    excluded={"10_COPIAS_SEGURIDAD","02_MEMORIA"}
    for p in workspace.rglob("*"):
        if p.is_file() and not excluded.intersection(x.name for x in p.parents):
            try: groups[(p.stat().st_size,digest(p))].append(p)
            except OSError: pass
    moved=0
    for _,paths in groups.items():
        if len(paths)<2: continue
        paths=sorted(paths,key=lambda x:x.stat().st_mtime)
        for p in paths[1:]:
            dest=unique(quarantine/p.name); dest.parent.mkdir(parents=True,exist_ok=True)
            shutil.move(str(p),str(dest))
            db.action("duplicado",p,f"Copia exacta movida a {dest}; original conservado: {paths[0]}",True)
            moved+=1
    return moved

def purge_quarantine(workspace: Path,db,days=30):
    q=workspace/"10_COPIAS_SEGURIDAD"/"CUARENTENA"
    cutoff=datetime.now()-timedelta(days=max(1,days))
    purged=0
    for p in list(q.rglob("*")):
        if p.is_file() and datetime.fromtimestamp(p.stat().st_mtime)<cutoff:
            send2trash(str(p))
            db.action("papelera",p,"Enviado automáticamente a la Papelera tras cuarentena.",True)
            purged+=1
    return purged

def inventory(workspace: Path):
    counts=defaultdict(int); total=0
    for p in workspace.rglob("*"):
        if p.is_file():
            counts[bucket_for(p)]+=1
            try: total+=p.stat().st_size
            except OSError: pass
    return dict(counts),total
