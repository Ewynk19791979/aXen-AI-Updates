from __future__ import annotations
import logging
from pathlib import Path

def setup_logging(workspace: Path):
    log_dir = workspace / "02_MEMORIA" / "INFORMES_AUTONOMOS"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "mi_ia.log"
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        handlers=[logging.FileHandler(log_file,encoding="utf-8")],
    )
    return log_file
