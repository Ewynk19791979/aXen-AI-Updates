from __future__ import annotations
import os, threading, traceback
from pathlib import Path
import tkinter as tk
from tkinter import ttk,filedialog,messagebox,simpledialog
from tkinter.scrolledtext import ScrolledText

from .config import APP_NAME,AppConfig,ensure_workspace
from .db import Database
from .seed_memory import SEED_MEMORIES
from .logging_setup import setup_logging
from .ai_client import ask,save_key,get_key,available_models
from .dae_analyzer import analyze,report
from .chatgpt_importer import import_export
from .file_ops import inventory,organize_inbox,quarantine_duplicates
from .autonomy import AutonomousWorker
from .updater import check_remote_manifest,current_version

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.app_dir=Path(__file__).resolve().parent.parent
        self.config_obj=AppConfig.load(self.app_dir)
        ensure_workspace(self.config_obj.workspace_path)
        setup_logging(self.config_obj.workspace_path)
        self.db=Database(self.config_obj.workspace_path/"02_MEMORIA"/"mi_ia.sqlite3")
        self.db.seed(SEED_MEMORIES)
        self.title(APP_NAME);self.geometry("1180x760");self.minsize(900,620)
        self.protocol("WM_DELETE_WINDOW",self.close)
        self._build()
        self.refresh_projects();self.refresh_memories();self.refresh_inventory()
        self.worker=AutonomousWorker(self,self.app_dir,self.config_obj.workspace_path,
                                     self.config_obj,self.db,self.set_status)
        if self.config_obj.autonomy:self.worker.start()
        core = "activadas" if self.config_obj.auto_update_core else "protegidas hasta configurar un canal"
        self.set_status(f"Mi IA está preparada. Actualizaciones del núcleo {core}.")

    def _build(self):
        style=ttk.Style(self)
        try:style.theme_use("clam")
        except Exception:pass
        top=ttk.Frame(self,padding=8);top.pack(fill="x")
        ttk.Label(top,text="MI IA · aXen Studio",font=("Segoe UI",18,"bold")).pack(side="left")
        self.status=tk.StringVar(value="")
        ttk.Label(top,textvariable=self.status).pack(side="right")

        self.tabs=ttk.Notebook(self);self.tabs.pack(fill="both",expand=True,padx=8,pady=(0,8))
        self.chat_tab=ttk.Frame(self.tabs);self.dae_tab=ttk.Frame(self.tabs)
        self.mem_tab=ttk.Frame(self.tabs);self.files_tab=ttk.Frame(self.tabs)
        self.config_tab=ttk.Frame(self.tabs);self.update_tab=ttk.Frame(self.tabs)
        for frame,name in [(self.chat_tab,"Compañera"),(self.dae_tab,"DAE"),
                           (self.mem_tab,"Memoria"),(self.files_tab,"Archivos"),
                           (self.config_tab,"Configuración"),(self.update_tab,"Actualizaciones")]:
            self.tabs.add(frame,text=name)
        self._chat();self._dae();self._memory();self._files();self._config();self._updates()

    def set_status(self,text): self.status.set(text[:180])

    def _chat(self):
        bar=ttk.Frame(self.chat_tab,padding=8);bar.pack(fill="x")
        ttk.Label(bar,text="Proyecto:").pack(side="left")
        self.project_var=tk.StringVar()
        self.projects_combo=ttk.Combobox(bar,textvariable=self.project_var,state="readonly",width=38)
        self.projects_combo.pack(side="left",padx=6)
        ttk.Button(bar,text="Nuevo proyecto",command=self.new_project).pack(side="left")
        self.chat=ScrolledText(self.chat_tab,wrap="word",font=("Segoe UI",11),state="disabled")
        self.chat.pack(fill="both",expand=True,padx=8)
        bottom=ttk.Frame(self.chat_tab,padding=8);bottom.pack(fill="x")
        self.prompt=ScrolledText(bottom,height=5,wrap="word",font=("Segoe UI",11))
        self.prompt.pack(side="left",fill="x",expand=True)
        ttk.Button(bottom,text="Enviar",command=self.send,height=3).pack(side="left",padx=(8,0))
        self.prompt.bind("<Control-Return>",lambda e:self.send())

    def append(self,who,text):
        self.chat.configure(state="normal")
        self.chat.insert("end",f"\n{who}\n{text}\n")
        self.chat.see("end");self.chat.configure(state="disabled")

    def refresh_projects(self):
        names=[r["name"] for r in self.db.projects()]
        self.projects_combo["values"]=names
        if names and self.project_var.get() not in names:self.project_var.set(names[0])

    def new_project(self):
        name=simpledialog.askstring("Nuevo proyecto","Nombre del proyecto:",parent=self)
        if not name:return
        try:self.db.add_project(name);(self.config_obj.workspace_path/"03_PROYECTOS"/name).mkdir(parents=True,exist_ok=True)
        except Exception as e:messagebox.showerror("Proyecto",str(e));return
        self.refresh_projects();self.project_var.set(name)

    def send(self):
        text=self.prompt.get("1.0","end").strip()
        if not text:return
        self.prompt.delete("1.0","end");self.append("ANTONIO",text)
        project=self.project_var.get() or "Tienda aXen Studio"
        row=self.db.project(project);pid=row["id"] if row else None
        self.db.add_message(pid,"user",text);self.set_status("Mi IA está trabajando…")
        def work():
            try:
                recent=self.db.recent_messages(pid)
                history="\n".join(f"{r['role'].upper()}: {r['content']}" for r in recent[:-1])
                answer,model=ask(self.config_obj.model,self.db.memory_context(),project,
                                 history,text,self.config_obj.web_search)
                self.db.add_message(pid,"assistant",answer)
                self.after(0,lambda:(self.append(f"MI IA · {model}",answer),
                                     self.set_status("Trabajo terminado.")))
            except Exception as e:
                self.after(0,lambda:self.handle_error(e))
        threading.Thread(target=work,daemon=True).start()

    def handle_error(self,e):
        self.set_status("Se produjo un error.")
        messagebox.showerror("Mi IA",str(e))

    def _dae(self):
        left=ttk.Frame(self.dae_tab,padding=10);left.pack(fill="x")
        ttk.Button(left,text="Estudiar archivo DAE",command=self.study_dae).pack(side="left")
        ttk.Button(left,text="Abrir carpeta de DAE",command=lambda:os.startfile(
            self.config_obj.workspace_path/"07_MESH"/"01_DAE_ORIGINALES")).pack(side="left",padx=8)
        self.dae_out=ScrolledText(self.dae_tab,wrap="word",font=("Consolas",10))
        self.dae_out.pack(fill="both",expand=True,padx=10,pady=(0,10))

    def study_dae(self):
        f=filedialog.askopenfilename(filetypes=[("COLLADA DAE","*.dae")])
        if not f:return
        try:
            path=Path(f);data=analyze(path);text=report(data)
            out=self.config_obj.workspace_path/"07_MESH"/"02_ESTUDIOS_TECNICOS"/(path.stem+"_ESTUDIO.txt")
            out.write_text(text,encoding="utf-8")
            originals=self.config_obj.workspace_path/"07_MESH"/"01_DAE_ORIGINALES"/path.name
            if not originals.exists():
                import shutil;shutil.copy2(path,originals)
            self.db.dae_study(path,data["sha256"],text)
            self.db.add_memory("dae_aprendido",f"Estudio de {path.name}: {data['geometries']} geometrías, "
                               f"{data['triangles']} triángulos declarados, {data['materials']} materiales.",8)
            self.dae_out.delete("1.0","end");self.dae_out.insert("1.0",text)
            self.refresh_memories();self.set_status(f"DAE estudiado y guardado: {out.name}")
        except Exception as e:self.handle_error(e)

    def _memory(self):
        bar=ttk.Frame(self.mem_tab,padding=8);bar.pack(fill="x")
        ttk.Button(bar,text="Añadir recuerdo",command=self.add_memory).pack(side="left")
        ttk.Button(bar,text="Eliminar seleccionado",command=self.delete_memory).pack(side="left",padx=6)
        ttk.Button(bar,text="Importar exportación ChatGPT",command=self.import_chatgpt).pack(side="left")
        self.mem_tree=ttk.Treeview(self.mem_tab,columns=("id","cat","pri","text"),show="headings")
        for c,t,w in [("id","ID",50),("cat","Categoría",160),("pri","Prioridad",70),("text","Recuerdo",780)]:
            self.mem_tree.heading(c,text=t);self.mem_tree.column(c,width=w,anchor="w")
        self.mem_tree.pack(fill="both",expand=True,padx=8,pady=(0,8))

    def refresh_memories(self):
        for x in self.mem_tree.get_children():self.mem_tree.delete(x)
        for r in self.db.memories():
            self.mem_tree.insert("","end",values=(r["id"],r["category"],r["priority"],r["content"]))

    def add_memory(self):
        cat=simpledialog.askstring("Memoria","Categoría:",parent=self)
        if not cat:return
        content=simpledialog.askstring("Memoria","Qué debe recordar:",parent=self)
        if not content:return
        pri=simpledialog.askinteger("Memoria","Prioridad 1-10:",initialvalue=7,minvalue=1,maxvalue=10,parent=self)
        self.db.add_memory(cat,content,pri or 7);self.refresh_memories()

    def delete_memory(self):
        sel=self.mem_tree.selection()
        if not sel:return
        mid=int(self.mem_tree.item(sel[0],"values")[0])
        self.db.delete_memory(mid);self.refresh_memories()

    def import_chatgpt(self):
        f=filedialog.askopenfilename(filetypes=[("Exportación ZIP","*.zip")])
        if not f:return
        self.set_status("Importando conversaciones…")
        def work():
            try:
                n=import_export(Path(f),self.db,self.config_obj.workspace_path/"02_MEMORIA"/"CHATGPT_IMPORTADO",
                                self.config_obj.import_max_conversations)
                self.after(0,lambda:(self.set_status(f"Importadas {n} conversaciones."),
                                     messagebox.showinfo("Memoria",f"Se importaron {n} conversaciones.")))
            except Exception as e:self.after(0,lambda:self.handle_error(e))
        threading.Thread(target=work,daemon=True).start()

    def _files(self):
        bar=ttk.Frame(self.files_tab,padding=8);bar.pack(fill="x")
        ttk.Button(bar,text="Ordenar entrada ahora",command=self.organize).pack(side="left")
        ttk.Button(bar,text="Buscar duplicados exactos",command=self.duplicates).pack(side="left",padx=6)
        ttk.Button(bar,text="Abrir Mi IA",command=lambda:os.startfile(self.config_obj.workspace_path)).pack(side="left")
        ttk.Button(bar,text="Actualizar inventario",command=self.refresh_inventory).pack(side="left",padx=6)
        self.inventory_text=ScrolledText(self.files_tab,font=("Consolas",11))
        self.inventory_text.pack(fill="both",expand=True,padx=8,pady=(0,8))

    def refresh_inventory(self):
        counts,total=inventory(self.config_obj.workspace_path)
        text="INVENTARIO DE MI IA\n===================\n\n"
        text+="\n".join(f"{k}: {v} archivos" for k,v in sorted(counts.items()))
        text+=f"\n\nTamaño total: {total/1024/1024:.2f} MB"
        self.inventory_text.delete("1.0","end");self.inventory_text.insert("1.0",text)

    def organize(self):
        n=organize_inbox(self.config_obj.workspace_path,self.db)
        self.refresh_inventory();self.set_status(f"Ordenados {n} archivos.")

    def duplicates(self):
        self.set_status("Comparando duplicados exactos…")
        def work():
            n=quarantine_duplicates(self.config_obj.workspace_path,self.db)
            self.after(0,lambda:(self.refresh_inventory(),self.set_status(f"{n} duplicados enviados a cuarentena.")))
        threading.Thread(target=work,daemon=True).start()

    def _config(self):
        f=ttk.Frame(self.config_tab,padding=18);f.pack(fill="both",expand=True)
        ttk.Label(f,text="Carpeta principal").grid(row=0,column=0,sticky="w")
        self.workspace_var=tk.StringVar(value=self.config_obj.workspace)
        ttk.Entry(f,textvariable=self.workspace_var,width=70).grid(row=0,column=1,sticky="ew",padx=8)
        ttk.Button(f,text="Elegir",command=self.choose_workspace).grid(row=0,column=2)
        ttk.Label(f,text="Modelo").grid(row=1,column=0,sticky="w",pady=8)
        self.model_var=tk.StringVar(value=self.config_obj.model)
        self.model_combo=ttk.Combobox(f,textvariable=self.model_var,width=50)
        self.model_combo.grid(row=1,column=1,sticky="w",padx=8)
        ttk.Button(f,text="Detectar modelos",command=self.detect_models).grid(row=1,column=2)
        ttk.Label(f,text="Clave API").grid(row=2,column=0,sticky="w")
        self.key_var=tk.StringVar(value="••••••••" if get_key() else "")
        ttk.Entry(f,textvariable=self.key_var,show="*",width=55).grid(row=2,column=1,sticky="w",padx=8)
        ttk.Button(f,text="Guardar clave",command=self.store_key).grid(row=2,column=2)
        self.web_var=tk.BooleanVar(value=self.config_obj.web_search)
        self.auto_var=tk.BooleanVar(value=self.config_obj.autonomy)
        self.dep_var=tk.BooleanVar(value=self.config_obj.auto_update_dependencies)
        self.core_var=tk.BooleanVar(value=self.config_obj.auto_update_core)
        ttk.Checkbutton(f,text="Búsqueda web cuando aporte información actual",variable=self.web_var).grid(row=3,column=1,sticky="w",pady=8)
        ttk.Checkbutton(f,text="Autonomía activa",variable=self.auto_var).grid(row=4,column=1,sticky="w")
        ttk.Checkbutton(f,text="Actualizar librerías automáticamente (solo con copia y comprobación)",variable=self.dep_var).grid(row=5,column=1,sticky="w")
        ttk.Checkbutton(f,text="Instalar automáticamente paquetes verificados del núcleo",variable=self.core_var).grid(row=6,column=1,sticky="w")
        ttk.Button(f,text="Guardar configuración",command=self.save_config).grid(row=7,column=1,sticky="w",pady=18)
        f.columnconfigure(1,weight=1)

    def choose_workspace(self):
        p=filedialog.askdirectory(initialdir=self.workspace_var.get())
        if p:self.workspace_var.set(p)

    def store_key(self):
        v=self.key_var.get()
        if v and v!="••••••••":
            try:save_key(v);self.key_var.set("••••••••");self.set_status("Clave guardada en el almacén seguro de Windows.")
            except Exception as e:self.handle_error(e)

    def detect_models(self):
        self.set_status("Consultando modelos disponibles…")
        def work():
            try:
                rows=available_models()
                self.after(0,lambda:(self.model_combo.configure(values=["auto"]+rows),
                                     self.set_status(f"Detectados {len(rows)} modelos.")))
            except Exception as e:self.after(0,lambda:self.handle_error(e))
        threading.Thread(target=work,daemon=True).start()

    def save_config(self):
        self.config_obj.workspace=self.workspace_var.get().strip()
        self.config_obj.model=self.model_var.get().strip() or "auto"
        self.config_obj.web_search=self.web_var.get()
        self.config_obj.autonomy=self.auto_var.get()
        self.config_obj.auto_update_dependencies=self.dep_var.get()
        self.config_obj.auto_update_core=self.core_var.get()
        ensure_workspace(self.config_obj.workspace_path);self.config_obj.save(self.app_dir)
        self.set_status("Configuración guardada. Reinicia para cambiar la carpeta principal.")

    def _updates(self):
        f=ttk.Frame(self.update_tab,padding=15);f.pack(fill="both",expand=True)
        ttk.Label(f,text="ACTUALIZACIONES SEGURAS",font=("Segoe UI",15,"bold")).pack(anchor="w")
        ttk.Label(f,wraplength=900,justify="left",text=
          f"Núcleo instalado: {current_version(self.app_dir)}. Los paquetes locales y remotos se validan "
          "antes de instalarse, se comprueba su versión y SHA-256, y se crea una copia completa. "
          "Mientras no exista un canal oficial, deja el campo HTTPS vacío.").pack(anchor="w",pady=10)
        ttk.Button(f,text="Ejecutar mantenimiento ahora",command=self.run_cycle).pack(anchor="w")
        ttk.Button(f,text="Abrir carpeta ACTUALIZACIONES",command=lambda:os.startfile(
            self.config_obj.workspace_path/"ACTUALIZACIONES")).pack(anchor="w",pady=8)
        ttk.Label(f,text="Canal HTTPS oficial del núcleo:").pack(anchor="w",pady=(18,0))
        self.manifest_var=tk.StringVar(value=self.config_obj.update_manifest_url)
        ttk.Entry(f,textvariable=self.manifest_var,width=95).pack(anchor="w",fill="x")
        buttons=ttk.Frame(f);buttons.pack(anchor="w",pady=8)
        ttk.Button(buttons,text="Guardar canal",command=self.save_manifest).pack(side="left")
        ttk.Button(buttons,text="Comprobar canal",command=self.check_manifest).pack(side="left",padx=8)
        ttk.Label(f,text="No pegues aquí la clave API. Este campo solo acepta la dirección HTTPS de channel.json.",
                  wraplength=900,justify="left").pack(anchor="w",pady=(4,0))

    def save_manifest(self):
        value=self.manifest_var.get().strip()
        if value and not value.lower().startswith("https://"):
            messagebox.showerror("Canal de actualización","El canal debe empezar por https://")
            return
        self.config_obj.update_manifest_url=value
        self.config_obj.save(self.app_dir)
        if value:
            self.set_status("Canal HTTPS guardado. Pulsa Comprobar canal antes de activar la instalación automática.")
        else:
            self.set_status("Canal remoto desactivado. Los paquetes locales siguen disponibles.")

    def check_manifest(self):
        value=self.manifest_var.get().strip()
        if not value:
            messagebox.showinfo("Canal de actualización","Todavía no hay un canal HTTPS configurado.")
            return
        self.set_status("Comprobando el canal HTTPS…")
        def work():
            try:
                info=check_remote_manifest(value,self.app_dir)
                if info["update_available"]:
                    text=f"Canal correcto. Disponible {info['version']} (instalada {info['current_version']})."
                else:
                    text=f"Canal correcto. Ya tienes la versión {info['current_version']}."
                self.after(0,lambda:(self.set_status(text),messagebox.showinfo("Canal de actualización",text)))
            except Exception as e:
                self.after(0,lambda:self.handle_error(e))
        threading.Thread(target=work,daemon=True).start()

    def run_cycle(self):
        self.set_status("Ejecutando mantenimiento autónomo…")
        threading.Thread(target=self.worker.run_cycle,daemon=True).start()

    def close(self):
        try:self.worker.stop()
        except Exception:pass
        self.destroy()

def run_app():
    App().mainloop()
