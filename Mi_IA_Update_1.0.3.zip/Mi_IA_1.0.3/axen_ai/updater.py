from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import zipfile
from datetime import datetime, timedelta
from pathlib import Path, PurePosixPath
from urllib.parse import urlparse

import requests
from packaging.version import InvalidVersion, Version

log = logging.getLogger("updater")

MANIFEST_LIMIT = 64 * 1024
ZIP_LIMIT = 250 * 1024 * 1024
ZIP_ENTRY_LIMIT = 6000
CHANNEL_ID = "axen-studio-stable"
USER_AGENT = "Mi-IA-aXen-Studio-Updater/1.0.3"
HEX64 = re.compile(r"^[0-9a-fA-F]{64}$")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def current_version(app_dir: Path) -> str:
    p = app_dir / "VERSION"
    return p.read_text(encoding="utf-8").strip() if p.exists() else "0.0.0"


def _parsed_version(value: str, label: str = "versión") -> Version:
    try:
        return Version(str(value).strip())
    except InvalidVersion as exc:
        raise ValueError(f"{label.capitalize()} no válida: {value!r}") from exc


def _https_url(value: str, label: str) -> str:
    value = str(value or "").strip()
    parsed = urlparse(value)
    if parsed.scheme.lower() != "https" or not parsed.netloc:
        raise ValueError(f"{label} debe ser una dirección HTTPS completa.")
    if parsed.username or parsed.password:
        raise ValueError(f"{label} no puede incluir usuario ni contraseña.")
    return value


def backup_app(app_dir: Path, workspace: Path) -> Path:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    dest = workspace / "10_COPIAS_SEGURIDAD" / "ACTUALIZACIONES" / f"app_{stamp}"
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(
        app_dir,
        dest,
        ignore=shutil.ignore_patterns(".venv", "__pycache__", "*.pyc"),
    )
    return dest


def update_dependencies(app_dir: Path, workspace: Path) -> str:
    """Actualiza dependencias con copia previa y comprobación de consistencia.

    Se ejecuta como máximo una vez cada siete días. Si existe requirements.lock.txt,
    se usa ese archivo para evitar saltos imprevisibles de versiones.
    """
    stamp = workspace / "11_CONFIGURACION" / "last_dependency_update.txt"
    stamp.parent.mkdir(parents=True, exist_ok=True)
    if stamp.exists():
        try:
            last = datetime.fromisoformat(stamp.read_text(encoding="utf-8").strip())
            if datetime.now() - last < timedelta(days=7):
                return "Librerías ya comprobadas esta semana."
        except Exception:
            pass

    req = app_dir / "requirements.lock.txt"
    if not req.exists():
        req = app_dir / "requirements.txt"
    if not req.exists():
        return "Sin archivo de dependencias."

    backups = workspace / "10_COPIAS_SEGURIDAD" / "ACTUALIZACIONES"
    backups.mkdir(parents=True, exist_ok=True)
    freeze = backups / ("dependencias_" + datetime.now().strftime("%Y%m%d_%H%M%S") + ".txt")

    before = subprocess.run(
        [sys.executable, "-m", "pip", "freeze"],
        capture_output=True,
        text=True,
        timeout=180,
    )
    if before.returncode == 0:
        freeze.write_text(before.stdout, encoding="utf-8")

    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "pip",
            "install",
            "--upgrade-strategy",
            "only-if-needed",
            "-r",
            str(req),
        ],
        capture_output=True,
        text=True,
        timeout=1200,
    )
    check = subprocess.run(
        [sys.executable, "-m", "pip", "check"],
        capture_output=True,
        text=True,
        timeout=180,
    )
    if result.returncode or check.returncode:
        if freeze.exists() and freeze.stat().st_size:
            subprocess.run(
                [sys.executable, "-m", "pip", "install", "--force-reinstall", "-r", str(freeze)],
                capture_output=True,
                text=True,
                timeout=1800,
            )
        detail = (result.stderr or check.stdout or check.stderr)[-2000:]
        raise RuntimeError("Actualización de librerías revertida: " + detail)

    stamp.write_text(datetime.now().isoformat(), encoding="utf-8")
    return "Librerías actualizadas y verificadas."


def _safe_member_path(staging: Path, member_name: str) -> Path:
    name = member_name.replace("\\", "/")
    pure = PurePosixPath(name)
    if pure.is_absolute() or ".." in pure.parts:
        raise ValueError(f"Ruta peligrosa dentro del ZIP: {member_name}")
    if pure.parts and ":" in pure.parts[0]:
        raise ValueError(f"Unidad no permitida dentro del ZIP: {member_name}")
    target = (staging / Path(*pure.parts)).resolve()
    root = staging.resolve()
    try:
        target.relative_to(root)
    except ValueError as exc:
        raise ValueError(f"El ZIP intenta escribir fuera de su carpeta: {member_name}") from exc
    return target


def _safe_extract_zip(zip_path: Path, staging: Path) -> None:
    with zipfile.ZipFile(zip_path) as zf:
        infos = zf.infolist()
        if len(infos) > ZIP_ENTRY_LIMIT:
            raise ValueError("La actualización contiene demasiados archivos.")
        total = sum(max(0, i.file_size) for i in infos)
        if total > ZIP_LIMIT:
            raise ValueError("La actualización descomprimida supera el límite de seguridad.")

        for info in infos:
            mode = (info.external_attr >> 16) & 0xFFFF
            if stat.S_ISLNK(mode):
                raise ValueError(f"El ZIP contiene un enlace no permitido: {info.filename}")
            target = _safe_member_path(staging, info.filename)
            if info.is_dir() or info.filename.endswith("/"):
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(info, "r") as src, target.open("wb") as dst:
                shutil.copyfileobj(src, dst, length=1024 * 1024)


def _validate_staging(staging: Path, expected_version: str | None = None) -> str:
    for needed in ("main.py", "axen_ai", "VERSION"):
        if not (staging / needed).exists():
            raise ValueError(f"Actualización incompleta: falta {needed}")

    package_version = (staging / "VERSION").read_text(encoding="utf-8").strip()
    parsed_package = _parsed_version(package_version, "versión del paquete")
    if expected_version is not None and parsed_package != _parsed_version(expected_version, "versión del manifiesto"):
        raise ValueError("La versión del ZIP no coincide con la versión anunciada por el canal.")

    compile_result = subprocess.run(
        [sys.executable, "-m", "compileall", "-q", str(staging)],
        capture_output=True,
        text=True,
        timeout=180,
    )
    if compile_result.returncode:
        raise RuntimeError("La actualización no compila: " + compile_result.stderr[-2000:])

    smoke = subprocess.run(
        [
            sys.executable,
            "-c",
            "from axen_ai.config import AppConfig; from axen_ai.updater import current_version; "
            "print(AppConfig.__name__, current_version(__import__('pathlib').Path('.')))",
        ],
        cwd=staging,
        capture_output=True,
        text=True,
        timeout=90,
    )
    if smoke.returncode:
        raise RuntimeError("La actualización no supera la prueba de arranque: " + smoke.stderr[-2000:])
    return package_version


def install_zip(
    zip_path: Path,
    app_dir: Path,
    workspace: Path,
    expected_version: str | None = None,
) -> str:
    with tempfile.TemporaryDirectory() as td:
        staging_root = Path(td) / "staging"
        staging_root.mkdir()
        _safe_extract_zip(zip_path, staging_root)

        children = list(staging_root.iterdir())
        staging = staging_root
        if len(children) == 1 and children[0].is_dir() and (children[0] / "main.py").exists():
            staging = children[0]

        package_version = _validate_staging(staging, expected_version)
        if _parsed_version(package_version) <= _parsed_version(current_version(app_dir)):
            raise ValueError(f"La versión {package_version} no es más nueva que la instalada.")

        backup = backup_app(app_dir, workspace)
        preserved = {".venv", "settings.json"}
        try:
            for item in list(app_dir.iterdir()):
                if item.name in preserved:
                    continue
                if item.is_dir():
                    shutil.rmtree(item)
                else:
                    item.unlink()
            for item in staging.iterdir():
                if item.name == "settings.json":
                    continue
                dest = app_dir / item.name
                if item.is_dir():
                    shutil.copytree(item, dest)
                else:
                    shutil.copy2(item, dest)
        except Exception:
            for item in list(app_dir.iterdir()):
                if item.name in preserved:
                    continue
                if item.is_dir():
                    shutil.rmtree(item)
                else:
                    item.unlink()
            for item in backup.iterdir():
                if item.name == "settings.json":
                    continue
                dest = app_dir / item.name
                if item.is_dir():
                    shutil.copytree(item, dest)
                else:
                    shutil.copy2(item, dest)
            raise

    return current_version(app_dir)


def local_updates(app_dir: Path, workspace: Path) -> list[str]:
    folder = workspace / "ACTUALIZACIONES"
    folder.mkdir(parents=True, exist_ok=True)
    packages = sorted(folder.glob("Mi_IA_Update_*.zip"))
    installed: list[str] = []

    for package in packages:
        try:
            version_text = package.stem.removeprefix("Mi_IA_Update_")
            version = _parsed_version(version_text, "versión del nombre del paquete")
            if version <= _parsed_version(current_version(app_dir)):
                package.rename(package.with_suffix(".omitido"))
                continue
            installed_version = install_zip(package, app_dir, workspace, str(version))
            package.rename(package.with_suffix(".instalado"))
            installed.append(installed_version)
        except Exception:
            log.exception("Fallo instalando %s", package)
            try:
                package.rename(package.with_suffix(".fallido"))
            except OSError:
                pass
    return installed


def _session() -> requests.Session:
    session = requests.Session()
    session.headers.update({"User-Agent": USER_AGENT, "Accept": "application/json"})
    return session


def _read_manifest(manifest_url: str) -> dict:
    manifest_url = _https_url(manifest_url, "El canal remoto")
    with _session().get(manifest_url, timeout=(10, 30), allow_redirects=True, stream=True) as response:
        response.raise_for_status()
        _https_url(response.url, "La dirección final del canal")
        length = response.headers.get("Content-Length")
        if length and int(length) > MANIFEST_LIMIT:
            raise ValueError("El manifiesto del canal es demasiado grande.")
        data = response.raw.read(MANIFEST_LIMIT + 1)
        if len(data) > MANIFEST_LIMIT:
            raise ValueError("El manifiesto del canal supera el límite de seguridad.")

    try:
        manifest = json.loads(data.decode("utf-8"))
    except Exception as exc:
        raise ValueError("El canal no contiene un JSON válido.") from exc
    if not isinstance(manifest, dict):
        raise ValueError("El manifiesto del canal debe ser un objeto JSON.")

    if manifest.get("channel") != CHANNEL_ID:
        raise ValueError("Este canal no pertenece a Mi IA · aXen Studio.")

    version = str(manifest.get("version", "")).strip()
    url = _https_url(manifest.get("url", ""), "El ZIP de actualización")
    expected = str(manifest.get("sha256", "")).strip().lower()
    if not HEX64.fullmatch(expected):
        raise ValueError("El manifiesto no contiene un SHA-256 válido.")

    size = manifest.get("size")
    if size is not None:
        try:
            size = int(size)
        except (TypeError, ValueError) as exc:
            raise ValueError("El tamaño anunciado no es válido.") from exc
        if size <= 0 or size > ZIP_LIMIT:
            raise ValueError("El tamaño anunciado supera el límite de seguridad.")

    _parsed_version(version, "versión del manifiesto")
    return {"channel": CHANNEL_ID, "version": version, "url": url, "sha256": expected, "size": size}


def check_remote_manifest(manifest_url: str, app_dir: Path) -> dict:
    manifest = _read_manifest(manifest_url)
    manifest["current_version"] = current_version(app_dir)
    manifest["update_available"] = (
        _parsed_version(manifest["version"]) > _parsed_version(manifest["current_version"])
    )
    return manifest


def remote_update(manifest_url: str, app_dir: Path, workspace: Path) -> str | None:
    if not manifest_url:
        return None

    manifest = _read_manifest(manifest_url)
    new_version = manifest["version"]
    if _parsed_version(new_version) <= _parsed_version(current_version(app_dir)):
        return None

    with tempfile.TemporaryDirectory() as td:
        target = Path(td) / "update.zip"
        h = hashlib.sha256()
        total = 0
        headers = {"User-Agent": USER_AGENT, "Accept": "application/zip, application/octet-stream"}
        with requests.get(
            manifest["url"],
            headers=headers,
            stream=True,
            timeout=(10, 180),
            allow_redirects=True,
        ) as response:
            response.raise_for_status()
            _https_url(response.url, "La dirección final del ZIP")
            length = response.headers.get("Content-Length")
            if length and int(length) > ZIP_LIMIT:
                raise ValueError("El ZIP remoto supera el límite de seguridad.")
            with target.open("wb") as f:
                for chunk in response.iter_content(1024 * 1024):
                    if not chunk:
                        continue
                    total += len(chunk)
                    if total > ZIP_LIMIT:
                        raise ValueError("El ZIP remoto supera el límite de seguridad.")
                    h.update(chunk)
                    f.write(chunk)

        if manifest["size"] is not None and total != manifest["size"]:
            raise ValueError("El tamaño descargado no coincide con el manifiesto.")
        if h.hexdigest().lower() != manifest["sha256"]:
            raise ValueError("SHA-256 incorrecto. La actualización ha sido rechazada.")

        return install_zip(target, app_dir, workspace, new_version)
