import tempfile
from pathlib import Path
from axen_ai.dae_analyzer import analyze

SAMPLE="""<?xml version="1.0" encoding="utf-8"?>
<COLLADA xmlns="http://www.collada.org/2005/11/COLLADASchema" version="1.4.1">
<asset><unit name="meter" meter="1"/><up_axis>Z_UP</up_axis></asset>
<library_geometries><geometry id="g"><mesh>
<source id="s"><float_array id="a" count="9">0 0 0 1 0 0 0 1 0</float_array></source>
<triangles count="1" material="mat"><p>0 1 2</p></triangles>
</mesh></geometry></library_geometries></COLLADA>"""

def test_analyze():
    with tempfile.TemporaryDirectory() as td:
        p=Path(td)/"x.dae";p.write_text(SAMPLE,encoding="utf-8")
        d=analyze(p)
        assert d["geometries"]==1
        assert d["triangles"]==1
        assert d["up_axis"]=="Z_UP"
